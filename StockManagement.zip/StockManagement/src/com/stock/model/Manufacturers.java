package com.stock.model;

public class Manufacturers {
private
int mId;
String mName;
String mEmail;
String mPhoneNo;

public Manufacturers() {
	// TODO Auto-generated constructor stub
}

public Manufacturers(int mId, String mName, String mEmail, String mPhoneNo) {
	super();
	this.mId = mId;
	this.mName = mName;
	this.mEmail = mEmail;
	this.mPhoneNo = mPhoneNo;
}

public int getmId() {
	return mId;
}

public void setmId(int mId) {
	this.mId = mId;
}

public String getmName() {
	return mName;
}

public void setmName(String mName) {
	this.mName = mName;
}

public String getmEmail() {
	return mEmail;
}

public void setmEmail(String mEmail) {
	this.mEmail = mEmail;
}

public String getmPhoneNo() {
	return mPhoneNo;
}

public void setmPhoneNo(String mPhoneNo) {
	this.mPhoneNo = mPhoneNo;
}


}
