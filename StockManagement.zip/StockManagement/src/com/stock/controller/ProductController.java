package com.stock.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.stock.model.Manufacturers;
import com.stock.model.Products;
import com.stock.service.MService;

/**
 * Servlet implementation class ProductController
 */
@WebServlet("/ProductController")
public class ProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	MService mService=new MService();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String ac=request.getParameter("act");
		if(ac!=null) {
			if(ac.equals("displayPList")) {
				displayPList(request,response);
			}
			if(ac.equals("displayPForm")) {
				displayPForm(request,response);
			}
			if(ac.equals("displayEditForm")) {
				displayEditForm(request,response);
			}
			if(ac.equals("deleteP")) {
				deleteP(request,response);
			}
			if(ac.equals("displayMPList")) {
				displayMPLIst(request,response);
			}
		}	}

	private void displayMPLIst(HttpServletRequest request, HttpServletResponse response) {
		int mId=Integer.parseInt(request.getParameter("id"));
		
		
	}

	private void deleteP(HttpServletRequest request, HttpServletResponse response) {
		try {
			int pId=Integer.parseInt(request.getParameter("id"));
			mService.deleteP(pId);
			response.sendRedirect(""+getServletContext().getContextPath()+"/ProductController?act=displayPList");
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	private void displayEditForm(HttpServletRequest request, HttpServletResponse response) {
		try {
			int pId=Integer.parseInt(request.getParameter("id"));
			Products products=mService.displayPEditForm(pId);
			
			request.setAttribute("products",products);
			RequestDispatcher rd=request.getRequestDispatcher("/WEB-INF/EditPDetails.jsp");
			rd.forward(request, response);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	private void displayPForm(HttpServletRequest request, HttpServletResponse response) {
		try {
			RequestDispatcher rd=request.getRequestDispatcher("/WEB-INF/AddProduct.jsp");
			rd.forward(request, response);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	private void displayPList(HttpServletRequest request, HttpServletResponse response) {
		try {
			List<Products> plist=mService.displayPList();
			request.setAttribute("pList", plist);
			RequestDispatcher requestDispatcher=request.getRequestDispatcher("/WEB-INF/DisplayPList.jsp");
			//response.sendRedirect(""+getServletContext().getContextPath()+"/WEB-INF/DisplayMList");
			requestDispatcher.forward(request, response);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String ac=request.getParameter("act");
		if(ac!=null) {
			if(ac.equals("addProduct")) {
				addProduct(request,response);
			}
			if(ac.equals("updatePDetails")) {
				updatePDetails(request,response);
			}
		}
	}

	private void updatePDetails(HttpServletRequest request, HttpServletResponse response) {
		int pId=Integer.parseInt(request.getParameter("pId"));
		String pName=request.getParameter("pName");
	int pQuantity=Integer.parseInt(request.getParameter("pQuantity"));
		double pPrice=Double.parseDouble(request.getParameter("pPrice"));
		Products products=new Products();
		products.setpId(pId);
		products.setpName(pName);
		products.setpQuantity(pQuantity);
		products.setpPrice(pPrice);
		mService.updatePDetails(products);
		try {
			response.sendRedirect(""+getServletContext().getContextPath()+"/ProductController?act=displayPList");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}

	private void addProduct(HttpServletRequest request, HttpServletResponse response) {
		String pName=request.getParameter("pName");
		int pQuantity=Integer.parseInt(request.getParameter("pQuantity"));
		double pPrice=Double.parseDouble(request.getParameter("pPrice"));
		Products products=new Products();
		products.setpName(pName);
		products.setpQuantity(pQuantity);
		products.setpPrice(pPrice);
		
		
		boolean result = mService.addProduct(products);
		try {
			response.sendRedirect(""+getServletContext().getContextPath()+"/ProductController?act=displayPList"); 
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
