package com.stock.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.stock.model.Manufacturers;
import com.stock.service.MService;

/**
 * Servlet implementation class ManufacturerController
 */
@WebServlet("/ManufacturerController")
public class ManufacturerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       MService mService=new MService();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ManufacturerController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String ac=request.getParameter("act");
		if(ac!=null) {
			if(ac.equals("displayMList")) {
				displayMList(request,response);
			}
			if(ac.equals("displayMForm")) {
				displayMForm(request,response);
			}
			if(ac.equals("displayEditForm")) {
				displayEditForm(request,response);
			}
			if(ac.equals("deleteM")) {
				deleteM(request,response);
			}
		}
		
	}

	private void deleteM(HttpServletRequest request, HttpServletResponse response) {
		try {
			int mId=Integer.parseInt(request.getParameter("id"));
			mService.deleteM(mId);
			response.sendRedirect(""+getServletContext().getContextPath()+"/ManufacturerController?act=displayMList");
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void displayEditForm(HttpServletRequest request, HttpServletResponse response) {
		try {
			int mId=Integer.parseInt(request.getParameter("id"));
			Manufacturers manufacturers=mService.displayEditForm(mId);
			
			request.setAttribute("manufacturers",manufacturers);
			RequestDispatcher rd=request.getRequestDispatcher("/WEB-INF/EditMDetails.jsp");
			rd.forward(request, response);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	private void displayMForm(HttpServletRequest request, HttpServletResponse response) {
		try {
			RequestDispatcher rd=request.getRequestDispatcher("/WEB-INF/AddManufacturer.jsp");
			rd.forward(request, response);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	private void displayMList(HttpServletRequest request, HttpServletResponse response) {
		try {
			List<Manufacturers> mlist=mService.displayMList();
			request.setAttribute("mList", mlist);
			RequestDispatcher requestDispatcher=request.getRequestDispatcher("/WEB-INF/DisplayMList.jsp");
			//response.sendRedirect(""+getServletContext().getContextPath()+"/WEB-INF/DisplayMList");
			requestDispatcher.forward(request, response);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String ac=request.getParameter("act");
		if(ac!=null) {
			if(ac.equals("addManufacturer")) {
				addManufacturer(request,response);
			}
			if(ac.equals("updateMDetails")) {
				updateMDetails(request,response);
			}
		}
		
	}

	private void updateMDetails(HttpServletRequest request, HttpServletResponse response) {
		int mId=Integer.parseInt(request.getParameter("mId"));
		String mName=request.getParameter("mName");
		String mEmail=request.getParameter("mEmail");
		String mPhoneNo=request.getParameter("mPhoneNo");
		Manufacturers manufacturers=new Manufacturers();
		manufacturers.setmId(mId);
		manufacturers.setmName(mName);
		manufacturers.setmEmail(mEmail);
		manufacturers.setmPhoneNo(mPhoneNo);
		mService.updateMDetails(manufacturers);
		try {
			response.sendRedirect(""+getServletContext().getContextPath()+"/ManufacturerController?act=displayMList");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}

	private void addManufacturer(HttpServletRequest request, HttpServletResponse response) {
		
		String mName=request.getParameter("mName");
		String mEmail=request.getParameter("mEmail");
		String mPhoneNo=request.getParameter("mPhoneNo");
		
		Manufacturers manufacturers=new Manufacturers();
		manufacturers.setmName(mName);
		manufacturers.setmEmail(mEmail);
		manufacturers.setmPhoneNo(mPhoneNo);
		
		boolean result = mService.addManufacturer(manufacturers);
		try {
			response.sendRedirect(""+getServletContext().getContextPath()+"/ManufacturerController?act=displayMList"); 
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}

}
